function main()
clc;
clear all;
%%               ?f?B????
Od=[5 5 10]
Link=[10 10 10]

kinematics(Od,Link);
%%               ???B????
%kinematics( JointAngle );
end